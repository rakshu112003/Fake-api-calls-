const apiURL = "https://jsonplaceholder.typicode.com/posts";

// GET Example
function getPost() {
  fetch(apiURL + "/1")
    .then(res => res.json())
    .then(data => {
      document.getElementById("output").innerText =
        "GET Response:\n" + JSON.stringify(data, null, 2);
    });
}

// POST Example
function createPost() {
  fetch(apiURL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      title: "My Interview Demo",
      body: "This is a fake created post",
      userId: 1
    })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("output").innerText =
      "POST Response:\n" + JSON.stringify(data, null, 2);
  });
}

// PUT Example
function updatePost() {
  fetch(apiURL + "/1", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      id: 1,
      title: "Updated Title",
      body: "This post is updated",
      userId: 1
    })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("output").innerText =
      "PUT Response:\n" + JSON.stringify(data, null, 2);
  });
}

// DELETE Example
function deletePost() {
  fetch(apiURL + "/1", {
    method: "DELETE"
  })
  .then(res => {
    document.getElementById("output").innerText =
      "DELETE Response: Status " + res.status;
  });
}
